<?php
session_start();
$conn = new mysqli("localhost", "root", "", "student_management");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_ic = $_POST['student_ic'];
    $father_ic = $_POST['father_ic'];

    // Fetch student details
    $sql = "SELECT name, primary_class, mykid_number, image_path FROM students WHERE student_ic = ? AND father_ic = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $student_ic, $father_ic);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        die("No student found with the provided details.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report View</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f8ff;
        }

        .background-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .background-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .report-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 25px;
            padding: 30px;
            width: 100%;
            max-width: 800px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header .student-info {
            text-align: right;
        }

        .header img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #ddd;
        }

        h2 {
            color: #2a2185;
            font-size: 1.8rem;
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            text-align: center;
            padding: 10px;
        }

        th {
            background-color: #2a2185;
            color: white;
        }

        .download-icon {
            color: #2a2185;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .download-icon:hover {
            color: #1a1571;
        }

        /* Media query for smaller screens */
        @media (max-width: 576px) {
            .header {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .header .student-info {
                text-align: center;
                margin-top: 10px;
            }

            .header img {
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="background-image">
        <img src="bgSSKP3.svg" alt="Background Image">
    </div>

    <div class="report-container">
        <div class="header">
            <!-- Student Image -->
            <img src="<?php echo htmlspecialchars($student['image_path']); ?>" alt="Student Image">

            <!-- Student Info -->
            <div class="student-info">
                <p><strong>Nama:</strong> <?php echo htmlspecialchars($student['name']); ?></p>
                <p><strong>Kelas:</strong> <?php echo htmlspecialchars($student['primary_class']); ?></p>
                <p><strong>No. MyKid:</strong> <?php echo htmlspecialchars($student['mykid_number']); ?></p>
            </div>
        </div>

        <h2>Maklumat Penilaian</h2>

        <!-- Report Table -->
        <table>
            <thead>
                <tr>
                    <th>Penilaian</th>
                    <th>Tarikh Upload</th>
                    <th>Laporan Penuh</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Penggal 1</td>
                    <td>2024-03-15</td>
                    <td>
                        <a href="generate_pdf.php?term=penggal1" class="download-icon" target="_blank">
                            <ion-icon name="download-outline"></ion-icon>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>Penggal 2</td>
                    <td>2024-06-20</td>
                    <td>
                        <a href="generate_pdf.php?term=penggal2" class="download-icon" target="_blank">
                            <ion-icon name="download-outline"></ion-icon>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td>Penggal 3</td>
                    <td>2024-11-10</td>
                    <td>
                        <a href="generate_pdf.php?term=penggal3" class="download-icon" target="_blank">
                            <ion-icon name="download-outline"></ion-icon>
                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Ionicons Script -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>