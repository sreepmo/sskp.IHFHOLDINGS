<?php
require('fpdf.php');

$report = $_POST['report'];

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Student Report', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, $report);
$pdf->Output('D', 'student_report.pdf');
?><?php
require('fpdf.php'); // Ensure FPDF library is included

// Check if the report data is received via POST
if (isset($_POST['report'])) {
    $report = $_POST['report'];

    // Create instance of FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Add title
    $pdf->Cell(0, 10, 'Student Report', 0, 1, 'C');
    $pdf->Ln(10); // Add a line break

    // Add the report content
    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, $report);

    // Output the PDF for download
    $pdf->Output('D', 'Student_Report.pdf'); // Force download with the name "Student_Report.pdf"
    exit();
} else {
    echo "No report data provided!";
    exit();
}
