<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Background */
        body {
            background-image: url('bgSSKP.png'); /* Ganti dengan gambar latar Anda */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Arial', sans-serif; /* Font sesuai desain sebelumnya */
        }

        /* Form Container */
        .login-container {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 40px 30px;
            border-radius: 25px; /* Radius besar */
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        /* Header */
        h2 {
            color: #2a2185;
            text-align: center;
            font-size: 1.8rem; /* Font size sesuai desain */
            margin-bottom: 20px;
            font-weight: bold; /* Menambahkan ketebalan */
        }

        /* Input Fields */
        .form-control {
            border-radius: 20px; /* Radius besar */
            padding: 12px;
            font-size: 1rem; /* Font size untuk konsistensi */
            border: 1px solid #ddd;
        }

        .form-control:focus {
            border-color: #2a2185;
            box-shadow: 0 0 8px rgba(42, 33, 133, 0.5);
        }

        /* Buttons */
        .btn-primary {
            background-color: #2a2185;
            border-color: #2a2185;
            border-radius: 25px; /* Tombol modern */
            padding: 10px 20px;
            font-size: 1.2rem;
            font-weight: bold; /* Font weight untuk tombol */
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #1a1571;
            box-shadow: 0 4px 12px rgba(42, 33, 133, 0.4);
        }

        /* Forgot Password Link */
        a {
            color: #2a2185;
            text-decoration: none;
            font-size: 0.9rem; /* Sesuaikan ukuran font */
        }

        a:hover {
            text-decoration: underline;
        }

        /* Media Query */
        @media (max-width: 576px) {
            .login-container {
                padding: 20px;
                border-radius: 20px;
            }

            h2 {
                font-size: 1.5rem;
            }

            .btn-primary {
                font-size: 1rem;
                padding: 10px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Sistem Semakan Keputusan Pentaksiran</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="dashboard.php">
            <div class="form-group">
                <label for="email">Email Pengguna</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Kata Laluan</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </form>
        <div class="text-center mt-3">
            <a href="#">Forgot Password?</a>
        </div>
    </div>
</body>
</html>
