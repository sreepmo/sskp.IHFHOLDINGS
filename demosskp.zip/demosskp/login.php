
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Semak sama ada admin telah log masuk
if (!isset($_SESSION['admins']) || empty($_SESSION['admins'])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="responsive.css">
</head>
<body>
    <div class="container">
        <!-- Navigation Sidebar -->
        <nav class="navigation">
            <ul>
                <li><a href="#"><span class="title">Admin Dashboard</span></a></li>
                <li><a href="dashboard.php"><span class="title">Dashboard</span></a></li>
                <li><a href="customers.php"><span class="title">Customers</span></a></li>
                <li><a href="messages.php"><span class="title">Messages</span></a></li>
                <li><a href="help.php"><span class="title">Help</span></a></li>
                <li><a href="settings.php"><span class="title">Settings</span></a></li>
                <li><a href="change_password.php"><span class="title">Password</span></a></li>
                <li><a href="logout.php"><span class="title">Sign Out</span></a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <main class="main">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['admin']); ?>!</h1>
        </main>
    </div>
</body>
</html>
