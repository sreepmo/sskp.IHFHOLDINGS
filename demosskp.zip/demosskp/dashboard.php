<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SSKP</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="form_style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* CSS untuk memastikan carta responsif */
        .charts {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 20px;
            margin: 20px 0;
        }

        .chart-container {
            flex: 1 1 calc(50% - 40px); /* Setiap carta ambil separuh ruang dengan jarak */
            max-width: 600px; /* Hadkan saiz maksimum carta */
            min-width: 300px; /* Saiz minimum untuk paparan kecil */
        }

        canvas {
            width: 100% !important;
            height: auto !important;
        }
    </style>
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="logo-apple"></ion-icon>
                        </span>
                        <span class="title">SSKP ADMIN</span>
                    </a>
                </li>

                <li>
                    <a href="dashboard.php" class="active">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="penyediaan_data.html">
                        <span class="icon">
                            <ion-icon name="clipboard-outline"></ion-icon>
                        </span>
                        <span class="title">Penyediaan Data</span>
                    </a>
                </li>

                <li>
                    <a href="penyediaan_laporan.html">
                        <span class="icon">
                            <ion-icon name="document-attach-outline"></ion-icon>
                        </span>
                        <span class="title">Penyediaan Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="senarai_pelajar.html">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Senarai Pelajar</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="settings-outline"></ion-icon>
                        </span>
                        <span class="title">Settings</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log Keluar</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="customer01.jpg" alt="">
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox">
    <div class="card">
        <div>
            <div class="numbers">1,504</div>
            <div class="cardName">Pengguna Harian</div>
        </div>

        <div class="iconBx">
            <ion-icon name="people-outline"></ion-icon> <!-- Ikon untuk pengguna -->
        </div>
    </div>

    <div class="card">
        <div>
            <div class="numbers">80</div>
            <div class="cardName">Sekolah Malaysia</div>
        </div>

        <div class="iconBx">
            <ion-icon name="school-outline"></ion-icon> <!-- Ikon untuk sekolah -->
        </div>
    </div>

    <div class="card">
        <div>
            <div class="numbers">284</div>
            <div class="cardName">Bilangan Guru</div>
        </div>

        <div class="iconBx">
            <ion-icon name="person-outline"></ion-icon> <!-- Ikon untuk guru -->
        </div>
    </div>

    <div class="card">
        <div>
            <div class="numbers">7,842</div>
            <div class="cardName">Bilangan Pelajar</div>
        </div>

        <div class="iconBx">
            <ion-icon name="book-outline"></ion-icon> <!-- Ikon untuk pelajar -->
        </div>
    </div>
</div>

            <!-- ==================== Charts Section ==================== -->
            <div class="charts">
                <div class="chart-container">
                    <canvas id="pieChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="lineChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- =========== Scripts ========= -->
    <script src="main.js"></script>

    <!-- Chart JS Initialization -->
    <script>
        // Pie Chart
        const ctx1 = document.getElementById('pieChart').getContext('2d');
        const pieChart = new Chart(ctx1, {
            type: 'pie',
            data: {
                labels: ['Pelajar Cemerlang', 'Lulus', 'Gagal'],
                datasets: [{
                    data: [40, 50, 10], // Data sample
                    backgroundColor: ['#4caf50', '#ffeb3b', '#f44336'],
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // Line Chart
        const ctx2 = document.getElementById('lineChart').getContext('2d');
        const lineChart = new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'], // Bulan-bulan
                datasets: [{
                    label: 'Prestasi Pelajar',
                    data: [65, 59, 80, 81, 56, 55], // Data prestasi
                    borderColor: '#2196f3',
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Bulan'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Skor'
                        }
                    }
                }
            }
        });
    </script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>
